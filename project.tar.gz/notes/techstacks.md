# Tech Stack

## Frontend
- **Framework**: Next.js 15.2.6 (App Router)
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 (using OKLCH colors & CSS-variable based theming)
- **Icons**: Custom SVG icons (lucide-inspired)
- **Animations**: CSS Keyframes & Tailwind transitions

## Data & Logic
- **Storage**: Local JSON files (Mock)
- **Matching**: Custom TypeScript reconciliation utility
- **State Management**: React `useState` and `useMemo`

## Design System
- **Colors**: OKLCH (Modern, wide-gamut color space)
- **Aesthetics**: Glassmorphism (Backdrop blur, saturated overlays, complex shadows)
- **Layout**: CSS Grid (Responsive 3-column workspace)
