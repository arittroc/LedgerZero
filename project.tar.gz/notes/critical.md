# Critical Project Architecture & Constraints

This document outlines the non-negotiable architectural decisions and operational requirements for LedgerZero. These components are critical for system integrity, deployment stability, and the core user experience.

## 1. System Design Overview

LedgerZero is built as a **fully containerized, full-stack Next.js application** utilizing a relational database for financial reconciliation.

- **Frontend/API**: Next.js 15 (App Router) serving both the UI and the reconciliation logic.
- **Data Layer**: Prisma ORM 7 interfacing with a PostgreSQL 15 database.
- **Infrastructure**: Docker Compose orchestrating the `web` and `db` services.
- **Matching Engine**: A custom TypeScript utility (`reconcileLedger.ts`) performing deterministic exact-amount matching.

## 2. Non-Negotiable Constraints

### A. Infrastructure & Deployment
- **Containerization**: The project MUST remain deployable via `docker-compose`. The `web` service's dependency on the `db` service's health check is mandatory to prevent runtime connection failures during boot.
- **Database Migrations**: The `Dockerfile` must maintain the shell-based `CMD` sequence: `npx prisma migrate deploy && npx tsx prisma/seed.ts && npm run start`. This ensures the database schema and initial data are always synchronized with the application version without manual intervention.
- **Networking**: The `DATABASE_URL` within the Docker environment must use the internal service name (`db`) rather than `localhost` or hardcoded IPs.

### B. Tech Stack & Versioning
- **Prisma 7**: The schema and client must adhere to Prisma 7 standards. Do not revert to older versions as the driver adapters and configuration (like the removal of `url` in `datasource` when using certain configs) are specific to this version.
- **Next.js 15 + React 19**: The project utilizes the latest App Router features. Do not introduce legacy `pages/` directory patterns.
- **Node.js 20+**: The base image and development environment must stay on Node 20 LTS or higher for compatibility with modern dependencies.

### C. Visual Integrity (The "Vibe")
- **OKLCH Color Space**: The design system relies on the OKLCH color space for wide-gamut, perceptually uniform colors. Do not convert these to Hex or RGB, as it will break the modern aesthetic and color-mixing logic.
- **Glassmorphism**: The UI uses specific `backdrop-blur` and saturated overlay values. Any CSS refactoring must preserve these visual properties to maintain the "high-fidelity" dashboard feel.
- **Tailwind CSS 4**: The styling is built on Tailwind 4. Avoid introducing conflicting CSS-in-JS libraries or legacy styling methods that bypass the Tailwind theme configuration.

### D. Data Integrity
- **Reconciliation Logic**: The reconciliation process uses a deterministic 1-to-1 match. Any updates to fuzzy matching or manual overrides must be implemented as *extensions* of the core logic, never replacing the ability to perform exact matches.
- **Financial Accuracy**: Amounts are handled as `Float` in the current prototype but must be treated with precision. Any future migration to `Decimal` must be handled across the entire stack (Prisma, API, and Frontend) simultaneously.

## 3. Security & Environment
- **Secrets Management**: Never commit `.env` files. The `.env.example` must be the sole source of truth for required variables.
- **Database Access**: The PostgreSQL container uses a named volume `postgres_data` for persistence. This volume must never be deleted in production environments without a verified backup.
